import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, SkipForward, SkipBack, Music, AlertCircle, ListMusic, Volume2, X } from 'lucide-react';

// Expanded Library of Chill/Study Music
// Using reliable FMA links and duplicates for demo stability where unique URLs aren't guaranteed to be permanent
const TRACKS = [
  { title: "Algorithms", artist: "Chad Crouch", url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/ccCommunity/Chad_Crouch/Arps/Chad_Crouch_-_Algorithms.mp3" },
  { title: "Shipping Lanes", artist: "Chad Crouch", url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/ccCommunity/Chad_Crouch/Arps/Chad_Crouch_-_Shipping_Lanes.mp3" },
  { title: "Platformer", artist: "Chad Crouch", url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/ccCommunity/Chad_Crouch/Arps/Chad_Crouch_-_Platformer.mp3" },
  { title: "Starlight", artist: "Chad Crouch", url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/ccCommunity/Chad_Crouch/Arps/Chad_Crouch_-_Starlight.mp3" },
  { title: "Night Owl", artist: "Study Vibes", url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/ccCommunity/Chad_Crouch/Arps/Chad_Crouch_-_Organisms.mp3" }, // Alternate
  { title: "Deep Focus", artist: "Ambient Flow", url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/no_curator/Kai_Engel/Satin/Kai_Engel_-_04_-_Sentinel.mp3" },
  { title: "Rainy Day", artist: "LoFi Dreamer", url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/ccCommunity/Chad_Crouch/Arps/Chad_Crouch_-_Ellipses.mp3" }, // Alternate
  { title: "Exam Prep", artist: "Brainwave", url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/ccCommunity/Chad_Crouch/Arps/Chad_Crouch_-_Algorithms.mp3" }, // Reusing robust link
  { title: "Coffee Shop", artist: "Chill Beats", url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/ccCommunity/Chad_Crouch/Arps/Chad_Crouch_-_Shipping_Lanes.mp3" }, // Reusing robust link
  { title: "Midnight Oil", artist: "Student FM", url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/ccCommunity/Chad_Crouch/Arps/Chad_Crouch_-_Platformer.mp3" }, // Reusing robust link
  { title: "Alpha Waves", artist: "Focus", url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/ccCommunity/Chad_Crouch/Arps/Chad_Crouch_-_Starlight.mp3" }, // Reusing robust link
  { title: "Library Silence", artist: "Quiet Mode", url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/ccCommunity/Chad_Crouch/Arps/Chad_Crouch_-_Organisms.mp3" },
  { title: "Sunday Morning", artist: "Relax", url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/no_curator/Kai_Engel/Satin/Kai_Engel_-_04_-_Sentinel.mp3" },
  { title: "Quantum Physics", artist: "Scholr Beats", url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/ccCommunity/Chad_Crouch/Arps/Chad_Crouch_-_Ellipses.mp3" },
  { title: "Graduation", artist: "Victory", url: "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/ccCommunity/Chad_Crouch/Arps/Chad_Crouch_-_Algorithms.mp3" }
];

export const MusicPlayer: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState(0);
  const [error, setError] = useState(false);
  const [showPlaylist, setShowPlaylist] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const playlistRef = useRef<HTMLDivElement>(null);

  // Close playlist when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (playlistRef.current && !playlistRef.current.contains(event.target as Node)) {
        setShowPlaylist(false);
      }
    };
    if (showPlaylist) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showPlaylist]);

  // Helper to safely play audio
  const playSafe = async () => {
    const audio = audioRef.current;
    if (!audio) return;

    try {
      await audio.play();
      setError(false);
    } catch (err: any) {
      if (err.name !== 'AbortError' && !err.message.includes('interrupted') && !err.message.includes('pause')) {
        console.warn("Audio playback failed:", err);
        if (err.name === 'NotSupportedError' || err.message.includes('source')) {
           setError(true);
           setTimeout(() => handleNext(), 1500);
        }
      }
    }
  };

  useEffect(() => {
    audioRef.current = new Audio();
    audioRef.current.crossOrigin = "anonymous";
    audioRef.current.loop = false;
    audioRef.current.volume = 0.5;

    const handleEnded = () => {
      setCurrentTrack((prev) => (prev + 1) % TRACKS.length);
    };

    audioRef.current.addEventListener('ended', handleEnded);

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.removeEventListener('ended', handleEnded);
        audioRef.current = null;
      }
    };
  }, []);

  // Handle Track Changes
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const changeTrack = async () => {
      try {
        audio.pause();
        await new Promise(r => setTimeout(r, 0));
        
        audio.src = TRACKS[currentTrack].url;
        audio.load();
        
        if (isPlaying) {
          playSafe();
        }
      } catch (e) {
        console.warn("Track change interruption handled", e);
      }
    };

    changeTrack();
  }, [currentTrack]);

  // Handle Play/Pause Toggle
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      if (audio.src) playSafe();
    } else {
      audio.pause();
    }
  }, [isPlaying]);

  const handleNext = () => {
    setCurrentTrack((prev) => (prev + 1) % TRACKS.length);
  };

  const handlePrev = () => {
    setCurrentTrack((prev) => (prev - 1 + TRACKS.length) % TRACKS.length);
  };

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const selectTrack = (index: number) => {
    setCurrentTrack(index);
    setIsPlaying(true);
  };

  return (
    <div className="fixed bottom-6 left-6 z-50 animate-fade-in-up" ref={playlistRef}>
      
      {/* Playlist Popup */}
      {showPlaylist && (
        <div className="absolute bottom-full left-0 mb-4 w-72 max-h-96 bg-white/90 dark:bg-black/90 backdrop-blur-xl border border-white/20 dark:border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-scale-in origin-bottom-left">
          <div className="p-4 border-b border-gray-200 dark:border-gray-800 flex justify-between items-center bg-gray-50/50 dark:bg-gray-800/50">
            <h3 className="font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <ListMusic className="w-4 h-4 text-brand-500" /> Study Playlist
            </h3>
            <button 
              onClick={() => setShowPlaylist(false)}
              className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          
          <div className="overflow-y-auto flex-1 p-2 space-y-1 custom-scrollbar">
            {TRACKS.map((track, idx) => (
              <button
                key={idx}
                onClick={() => selectTrack(idx)}
                className={`w-full text-left p-3 rounded-xl flex items-center justify-between transition-all group ${
                  currentTrack === idx 
                    ? 'bg-brand-50 dark:bg-brand-900/30 border border-brand-200 dark:border-brand-800' 
                    : 'hover:bg-gray-100 dark:hover:bg-gray-800 border border-transparent'
                }`}
              >
                <div className="flex-1 min-w-0 mr-3">
                  <p className={`text-sm font-bold truncate ${currentTrack === idx ? 'text-brand-600 dark:text-brand-400' : 'text-gray-800 dark:text-gray-200'}`}>
                    {track.title}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
                    {track.artist}
                  </p>
                </div>
                {currentTrack === idx && isPlaying && (
                  <div className="flex gap-0.5 items-end h-4">
                    <div className="w-1 bg-brand-500 animate-[pulse_0.6s_ease-in-out_infinite] h-2"></div>
                    <div className="w-1 bg-brand-500 animate-[pulse_0.8s_ease-in-out_infinite] h-4"></div>
                    <div className="w-1 bg-brand-500 animate-[pulse_0.5s_ease-in-out_infinite] h-3"></div>
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Main Player Bar */}
      <div className={`glass-card p-3 rounded-2xl flex items-center gap-3 pr-5 bg-white/80 dark:bg-black/80 backdrop-blur-xl border ${error ? 'border-red-400' : 'border-white/20 dark:border-white/10'} shadow-2xl transition-all hover:scale-[1.02]`}>
        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center relative overflow-hidden flex-shrink-0 ${isPlaying ? 'shadow-lg shadow-indigo-500/30' : ''}`}>
           {isPlaying && (
             <div className="absolute inset-0 bg-black/10 flex items-center justify-center gap-1">
               <div className="w-1 bg-white/60 animate-[pulse_0.6s_ease-in-out_infinite] h-3"></div>
               <div className="w-1 bg-white/60 animate-[pulse_0.8s_ease-in-out_infinite] h-5"></div>
               <div className="w-1 bg-white/60 animate-[pulse_0.5s_ease-in-out_infinite] h-4"></div>
             </div>
           )}
          {error ? <AlertCircle className="w-5 h-5 text-white z-10" /> : <Music className="w-5 h-5 text-white z-10" />}
        </div>
        
        <div className="flex flex-col w-32 sm:w-40">
          <span className="text-xs font-bold text-gray-900 dark:text-white truncate">
            {error ? "Loading..." : TRACKS[currentTrack].title}
          </span>
          <span className="text-[10px] text-gray-500 dark:text-gray-400 font-medium truncate">
             {error ? "Retrying..." : TRACKS[currentTrack].artist}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={handlePrev}
            className="p-1.5 hover:bg-black/5 dark:hover:bg-white/10 rounded-lg transition-colors text-gray-700 dark:text-gray-300"
            title="Previous"
          >
            <SkipBack className="w-4 h-4" />
          </button>
          
          <button 
            onClick={togglePlay}
            className="p-2 bg-brand-600 hover:bg-brand-700 text-white rounded-xl transition-all shadow-md hover:shadow-brand-500/30 active:scale-95"
            title={isPlaying ? "Pause" : "Play"}
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>
          
          <button 
            onClick={handleNext}
            className="p-1.5 hover:bg-black/5 dark:hover:bg-white/10 rounded-lg transition-colors text-gray-700 dark:text-gray-300"
            title="Next"
          >
            <SkipForward className="w-4 h-4" />
          </button>

          <div className="w-px h-6 bg-gray-300 dark:bg-gray-700 mx-1"></div>

          <button
             onClick={() => setShowPlaylist(!showPlaylist)}
             className={`p-1.5 rounded-lg transition-colors ${showPlaylist ? 'bg-brand-100 text-brand-600 dark:bg-brand-900/30 dark:text-brand-400' : 'hover:bg-black/5 dark:hover:bg-white/10 text-gray-700 dark:text-gray-300'}`}
             title="Playlist"
          >
            <ListMusic className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
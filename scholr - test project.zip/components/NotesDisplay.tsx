import React, { useEffect, useState, useRef } from 'react';
import { StudyNote, User } from '../types';
import { BookOpen, Lightbulb, CheckCircle, ArrowLeft, AlertTriangle, HelpCircle, Globe, ImageIcon, Loader2, Sparkles, Bookmark, ExternalLink, ImageOff, RefreshCw } from 'lucide-react';
import { findRelatedImage, WebImageResult } from '../services/geminiService';
import { addBookmark, isBookmarked, removeBookmark, getBookmarks } from '../services/userService';

interface NotesDisplayProps {
  data: StudyNote;
  user: User | null;
  onBack: () => void;
  onAskTutor: (text: string) => void;
  onLoginRequest: () => void;
  scrollToSectionIndex?: number;
}

const WebImage: React.FC<{ searchQuery: string; alt: string }> = ({ searchQuery, alt }) => {
  const [imageData, setImageData] = useState<WebImageResult | null>(null);
  const [status, setStatus] = useState<'idle' | 'fetching' | 'loaded' | 'error'>('idle');
  const containerRef = useRef<HTMLDivElement>(null);

  // Lazy Load Trigger using IntersectionObserver
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && status === 'idle') {
          setStatus('fetching');
        }
      },
      { rootMargin: '200px', threshold: 0.01 } 
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => observer.disconnect();
  }, [status]);

  // Data Fetching Logic
  useEffect(() => {
    if (status !== 'fetching') return;

    let mounted = true;
    const fetchImage = async () => {
      try {
        const result = await findRelatedImage(searchQuery);
        if (mounted) {
          if (result && result.imageUrl) {
            setImageData(result);
            // Note: We stay in 'fetching' state visually until the <img> onLoad triggers 'loaded'
            // This prevents the "flash" of empty space between data fetch and image render
          } else {
            setStatus('error');
          }
        }
      } catch (e) {
        console.error("Image fetch failed", e);
        if (mounted) setStatus('error');
      }
    };

    fetchImage();
    return () => { mounted = false; };
  }, [status, searchQuery]);

  const handleRetry = (e: React.MouseEvent) => {
    e.stopPropagation();
    setStatus('fetching');
  };

  return (
    <div 
      ref={containerRef}
      className={`relative w-full rounded-2xl overflow-hidden border border-white/20 dark:border-white/10 bg-gray-100 dark:bg-gray-800 hardware-accelerated transition-shadow duration-500 group ${
        status === 'loaded' ? 'shadow-xl' : 'shadow-sm'
      }`}
      style={{ minHeight: '300px' }} // Reserve space to reduce CLS (Cumulative Layout Shift)
    >
      {/* 1. Animated Gradient Skeleton (Placeholder) */}
      <div 
        className={`absolute inset-0 z-0 transition-opacity duration-700 ${
          status === 'loaded' ? 'opacity-0' : 'opacity-100'
        }`}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-gray-200 via-gray-300 to-gray-200 dark:from-gray-800 dark:via-gray-700 dark:to-gray-800 animate-pulse" />
        
        {/* Loading Indicator */}
        {(status === 'fetching') && (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-4 z-10">
            <div className="relative">
               <div className="w-12 h-12 rounded-full border-4 border-gray-300 dark:border-gray-600 border-t-brand-500 animate-spin mb-4 shadow-sm"></div>
               <div className="absolute inset-0 flex items-center justify-center">
                 <ImageIcon className="w-4 h-4 text-gray-400" />
               </div>
            </div>
            <p className="text-gray-500 dark:text-gray-400 font-medium text-xs uppercase tracking-wider animate-pulse">
              Finding visual...
            </p>
          </div>
        )}
      </div>

      {/* 2. Actual Image with Smooth Fade-In */}
      {imageData && (
        <img 
          src={imageData.imageUrl} 
          alt={alt}
          onLoad={() => setStatus('loaded')}
          onError={() => setStatus('error')}
          className={`relative z-10 w-full h-auto object-cover min-h-[300px] max-h-[500px] transition-all duration-1000 ease-spring ${
            status === 'loaded' 
              ? 'opacity-100 scale-100 blur-0' 
              : 'opacity-0 scale-105 blur-lg'
          }`}
        />
      )}

      {/* 3. Error State with Retry */}
      {status === 'error' && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-gray-50/90 dark:bg-gray-800/90 backdrop-blur-sm p-6 text-center animate-fade-in-up">
          <div className="w-12 h-12 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center mb-3">
            <ImageOff className="w-6 h-6 text-gray-400 dark:text-gray-500" />
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400 font-medium mb-3 max-w-[80%]">
             Unable to load visual for this section.
          </p>
          <button 
            onClick={handleRetry}
            className="flex items-center px-4 py-2 bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 text-xs font-bold rounded-full shadow-sm border border-gray-200 dark:border-gray-600 hover:scale-105 hover:bg-gray-50 dark:hover:bg-gray-600 transition-all"
          >
            <RefreshCw className="w-3 h-3 mr-2" /> Retry
          </button>
        </div>
      )}

      {/* 4. Metadata Overlay (Only on hover + loaded) */}
      {status === 'loaded' && imageData && (
        <div className="absolute bottom-0 left-0 right-0 z-30 bg-white/90 dark:bg-black/80 backdrop-blur-md p-3 border-t border-white/20 dark:border-white/10 flex justify-between items-center transition-transform duration-300 translate-y-full group-hover:translate-y-0">
          <div className="flex-1 min-w-0 mr-2">
              <p className="text-gray-900 dark:text-gray-100 text-xs font-bold truncate">
                 {imageData.title || 'Source Image'}
              </p>
              <p className="text-gray-500 dark:text-gray-400 text-[10px] truncate">
                  {imageData.sourceUrl}
              </p>
          </div>
          <a 
              href={imageData.sourceUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-2 bg-brand-100 dark:bg-brand-900/40 text-brand-600 dark:text-brand-400 rounded-lg hover:bg-brand-200 dark:hover:bg-brand-900/60 transition-colors"
              title="Visit Source"
          >
              <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      )}

      {/* 5. Static Web Source Label (Hides on Hover) */}
      {status === 'loaded' && (
        <div className="absolute bottom-3 right-3 z-20 px-2 py-1 bg-black/40 backdrop-blur-md rounded-lg text-[10px] text-white/90 font-medium group-hover:opacity-0 transition-opacity">
          Web Source
        </div>
      )}
    </div>
  );
};

export const NotesDisplay: React.FC<NotesDisplayProps> = ({ data, user, onBack, onAskTutor, onLoginRequest, scrollToSectionIndex }) => {
  const [contextMenu, setContextMenu] = useState<{ x: number, y: number, text: string } | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [bookmarkedTopic, setBookmarkedTopic] = useState(false);
  const [bookmarkedSections, setBookmarkedSections] = useState<number[]>([]);

  // Check bookmark status on mount
  useEffect(() => {
    if (user) {
      setBookmarkedTopic(isBookmarked(user.id, data.topic));
      const sectionIndices = data.sections.map((_, idx) => idx).filter(idx => isBookmarked(user.id, data.topic, idx));
      setBookmarkedSections(sectionIndices);
    }
  }, [user, data]);

  // Handle Scroll to Section
  useEffect(() => {
    if (scrollToSectionIndex !== undefined && scrollToSectionIndex >= 0) {
      const el = document.getElementById(`section-${scrollToSectionIndex}`);
      if (el) {
        setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'center' }), 600);
      }
    }
  }, [scrollToSectionIndex]);

  useEffect(() => {
    const handleClick = () => setContextMenu(null);
    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, []);

  const handleContextMenu = (e: React.MouseEvent) => {
    const selection = window.getSelection();
    if (selection && selection.toString().trim().length > 0) {
      e.preventDefault();
      setContextMenu({
        x: e.pageX,
        y: e.pageY,
        text: selection.toString().trim()
      });
    }
  };

  const toggleTopicBookmark = () => {
    if (!user) {
      onLoginRequest();
      return;
    }
    if (bookmarkedTopic) {
      const bookmarks = getBookmarks(user.id);
      const bm = bookmarks.find(b => b.type === 'topic' && b.noteData.topic === data.topic);
      if (bm) removeBookmark(user.id, bm.id);
      setBookmarkedTopic(false);
    } else {
      addBookmark(user.id, data, 'topic');
      setBookmarkedTopic(true);
    }
  };

  const toggleSectionBookmark = (idx: number) => {
    if (!user) {
      onLoginRequest();
      return;
    }
    if (bookmarkedSections.includes(idx)) {
       const bookmarks = getBookmarks(user.id);
       const bm = bookmarks.find(b => b.type === 'section' && b.noteData.topic === data.topic && b.sectionIndex === idx);
       if (bm) removeBookmark(user.id, bm.id);
       setBookmarkedSections(prev => prev.filter(i => i !== idx));
    } else {
      addBookmark(user.id, data, 'section', idx);
      setBookmarkedSections(prev => [...prev, idx]);
    }
  };

  return (
    <div 
      className="max-w-5xl mx-auto pb-20 relative px-4"
      ref={containerRef}
      onContextMenu={handleContextMenu}
    >
      {/* Context Menu - Glass */}
      {contextMenu && (
        <div 
          className="absolute z-50 rounded-xl shadow-2xl p-1 animate-scale-in origin-top-left glass-card"
          style={{ top: contextMenu.y, left: contextMenu.x }}
        >
          <button
            onClick={(e) => {
              e.stopPropagation();
              onAskTutor(contextMenu.text);
              setContextMenu(null);
            }}
            className="flex items-center gap-2 px-4 py-2 text-sm text-gray-800 dark:text-gray-100 hover:bg-brand-50/50 dark:hover:bg-brand-900/20 hover:text-brand-600 dark:hover:text-brand-400 rounded-lg w-full text-left transition-colors font-medium backdrop-blur-sm"
          >
            <Sparkles className="w-4 h-4" />
            Ask AI Tutor
          </button>
        </div>
      )}

      {/* Navigation */}
      <button 
        onClick={onBack}
        className="flex items-center text-sm font-semibold text-gray-600 hover:text-brand-600 dark:text-gray-300 dark:hover:text-brand-400 mb-8 transition-all px-4 py-2.5 bg-white/40 dark:bg-black/20 rounded-xl backdrop-blur-md border border-white/20 w-fit hover:scale-105 active:scale-95 duration-200 shadow-sm"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to topics
      </button>

      {/* Header Section - Glass */}
      <div className="rounded-[2rem] p-8 sm:p-12 mb-12 relative overflow-hidden glass-card animate-fade-in-up hardware-accelerated">
        <div className="absolute top-0 right-0 w-80 h-80 bg-brand-500/10 dark:bg-brand-500/20 rounded-full blur-[100px] transform translate-x-1/3 -translate-y-1/3 pointer-events-none"></div>
        <div className="relative z-10">
          <div className="flex justify-between items-start">
            <div className="flex flex-wrap items-center gap-3 mb-8">
              <span className="px-4 py-1.5 text-xs font-bold uppercase tracking-wider rounded-full bg-brand-100/60 text-brand-700 dark:bg-brand-900/40 dark:text-brand-300 backdrop-blur-sm border border-brand-200/50 dark:border-brand-700/50">
                {data.classLevel}
              </span>
              <span className="px-4 py-1.5 text-xs font-bold uppercase tracking-wider rounded-full bg-purple-100/60 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300 backdrop-blur-sm border border-purple-200/50 dark:border-purple-700/50">
                {data.subject}
              </span>
            </div>
            
            <button 
              onClick={toggleTopicBookmark}
              className={`p-3 rounded-full transition-all duration-300 ease-spring ${
                bookmarkedTopic 
                  ? 'bg-brand-500 text-white shadow-lg shadow-brand-500/40 scale-110' 
                  : 'bg-white/50 dark:bg-white/10 text-gray-500 dark:text-gray-400 hover:bg-white/80 dark:hover:bg-white/20 hover:scale-105'
              }`}
              title={bookmarkedTopic ? "Remove Bookmark" : "Bookmark Topic"}
            >
              <Bookmark className={`w-6 h-6 ${bookmarkedTopic ? 'fill-current' : ''}`} />
            </button>
          </div>
          
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-gray-900 dark:text-white mb-8 leading-[1.1] tracking-tight drop-shadow-sm">
            {data.topic}
          </h1>
          <div className="prose prose-lg dark:prose-invert max-w-none text-gray-700 dark:text-gray-200 border-l-4 border-brand-500 pl-6 py-2">
            <p className="leading-relaxed font-medium opacity-90">{data.introduction}</p>
          </div>
        </div>
      </div>

      {/* Main Content Sections */}
      <div className="space-y-16 mb-16">
        {data.sections.map((section, idx) => (
          <div 
            id={`section-${idx}`}
            key={idx} 
            className={`rounded-[2rem] p-6 sm:p-10 transition-all duration-500 hover:shadow-2xl glass-card animate-fade-in-up border-2 hardware-accelerated ${
              scrollToSectionIndex === idx ? 'border-brand-500 ring-4 ring-brand-500/20' : 'border-transparent'
            }`}
            style={{ animationDelay: `${idx * 150}ms` }}
          >
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center">
                <span className="flex-shrink-0 w-12 h-12 rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 text-white flex items-center justify-center text-xl font-bold mr-5 shadow-lg shadow-brand-500/30">
                  {idx + 1}
                </span>
                <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white">
                  {section.heading}
                </h2>
              </div>
              
              <button 
                onClick={() => toggleSectionBookmark(idx)}
                className={`p-2 rounded-xl transition-all duration-300 ease-spring ${
                  bookmarkedSections.includes(idx)
                    ? 'text-purple-600 dark:text-purple-400 bg-purple-100 dark:bg-purple-900/30'
                    : 'text-gray-400 hover:text-purple-500 hover:bg-purple-50 dark:hover:bg-purple-900/10'
                }`}
                title="Bookmark Section"
              >
                <Bookmark className={`w-6 h-6 ${bookmarkedSections.includes(idx) ? 'fill-current' : ''}`} />
              </button>
            </div>
            
            {/* Content Points - Staggered entrance */}
            <div className="mb-10 pl-2">
               <ul className="space-y-6">
                 {section.contentPoints.map((point, ptIdx) => (
                   <li key={ptIdx} className="flex items-start group animate-slide-in-right" style={{ animationDelay: `${(idx * 100) + (ptIdx * 50)}ms` }}>
                     <span className="flex-shrink-0 w-2 h-2 mt-3 rounded-full bg-brand-400 dark:bg-brand-500 mr-5 group-hover:scale-150 transition-transform duration-300 ease-spring shadow-[0_0_15px_rgba(59,130,246,0.6)]" />
                     <p className="text-gray-800 dark:text-gray-200 text-lg leading-relaxed font-medium">
                       {point}
                     </p>
                   </li>
                 ))}
               </ul>
            </div>

            {/* Generated Image (Now Web Image) */}
            {section.imageDescription && (
              <div className="mb-10 animate-fade-in-up" style={{ animationDelay: '200ms' }}>
                <WebImage 
                  searchQuery={section.imageDescription} 
                  alt={section.heading + " Diagram"} 
                />
              </div>
            )}

            {/* Bullet Points & Key Terms - Glass inner cards */}
            <div className="grid md:grid-cols-2 gap-6">
              {section.bulletPoints && section.bulletPoints.length > 0 && (
                <div className="bg-blue-50/50 dark:bg-blue-900/10 rounded-3xl p-6 border border-blue-100/50 dark:border-blue-800/30 backdrop-blur-sm hover:scale-[1.02] transition-transform duration-400 ease-spring">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-blue-800 dark:text-blue-300 mb-4 flex items-center">
                    <CheckCircle className="w-5 h-5 mr-2" /> Quick Takeaways
                  </h3>
                  <ul className="space-y-3">
                    {section.bulletPoints.map((bp, i) => (
                      <li key={i} className="text-blue-900 dark:text-blue-100 flex items-start text-base font-medium">
                        <span className="mr-2.5 text-blue-500">•</span> {bp}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {section.importantTerms && section.importantTerms.length > 0 && (
                <div className="bg-amber-50/50 dark:bg-amber-900/10 rounded-3xl p-6 border border-amber-100/50 dark:border-amber-800/30 backdrop-blur-sm hover:scale-[1.02] transition-transform duration-400 ease-spring">
                   <h3 className="text-sm font-bold uppercase tracking-wider text-amber-800 dark:text-amber-300 mb-4 flex items-center">
                    <Lightbulb className="w-5 h-5 mr-2" /> Vocabulary
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {section.importantTerms.map((term, i) => (
                      <span key={i} className="inline-block px-3 py-1.5 bg-amber-100/50 dark:bg-amber-900/40 text-amber-900 dark:text-amber-100 text-sm rounded-lg font-bold border border-amber-200/50 dark:border-amber-800/50 backdrop-blur-sm">
                        {term}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Solved Questions Section */}
      {data.solvedQuestions && data.solvedQuestions.length > 0 && (
        <div className="mb-12 animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 flex items-center">
             <span className="p-2 bg-green-100/50 dark:bg-green-900/30 rounded-xl mr-3 border border-green-200/30 backdrop-blur-sm">
              <HelpCircle className="w-6 h-6 text-green-600 dark:text-green-400" />
             </span>
             Solved Examples
          </h2>
          <div className="grid gap-6">
            {data.solvedQuestions.map((sq, i) => (
              <div key={i} className="glass-card rounded-[2rem] p-6 sm:p-8 hover:scale-[1.01] transition-transform duration-400 ease-spring border-l-8 border-l-green-500">
                <div className="flex items-start mb-4">
                  <span className="flex-shrink-0 w-8 h-8 bg-green-100/80 dark:bg-green-900/40 rounded-full flex items-center justify-center text-green-700 dark:text-green-400 font-bold text-sm mr-3 mt-1 shadow-sm">
                    Q{i+1}
                  </span>
                  <h3 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-white">{sq.question}</h3>
                </div>
                <div className="pl-11">
                  <div className="bg-gray-50/60 dark:bg-black/30 rounded-2xl p-5 border border-gray-100 dark:border-gray-800 backdrop-blur-sm">
                    <p className="text-sm font-bold text-green-600 dark:text-green-400 mb-2 uppercase tracking-wide">Solution:</p>
                    <div className="text-gray-800 dark:text-gray-200 whitespace-pre-line leading-relaxed font-medium">
                      {sq.solution}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Additional Info Grid */}
      <div className="grid md:grid-cols-2 gap-8 mb-12 animate-fade-in-up" style={{ animationDelay: '0.5s' }}>
        {/* Real World Applications */}
        {data.realWorldApplications && data.realWorldApplications.length > 0 && (
          <div className="glass-card rounded-[2rem] p-8 h-full hover:scale-[1.02] transition-transform duration-400 ease-spring">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center">
              <Globe className="w-6 h-6 mr-3 text-indigo-500" /> Real World Applications
            </h3>
            <ul className="space-y-4">
              {data.realWorldApplications.map((app, i) => (
                <li key={i} className="flex items-start text-gray-700 dark:text-gray-200 font-medium group">
                  <span className="flex-shrink-0 w-2 h-2 rounded-full bg-indigo-500 mt-2 mr-3 group-hover:scale-150 transition-transform duration-300" />
                  <span>{app}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Common Mistakes */}
        {data.commonMistakes && data.commonMistakes.length > 0 && (
           <div className="glass-card rounded-[2rem] p-8 h-full hover:scale-[1.02] transition-transform duration-400 ease-spring">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center text-red-600 dark:text-red-400">
              <AlertTriangle className="w-6 h-6 mr-3" /> Common Mistakes
            </h3>
            <ul className="space-y-4">
              {data.commonMistakes.map((mistake, i) => (
                <li key={i} className="flex items-start bg-red-50/50 dark:bg-red-900/10 p-4 rounded-2xl text-red-900 dark:text-red-100 text-sm font-medium border border-red-100/30 transition-transform hover:translate-x-1 duration-200">
                  <span className="font-bold mr-2 text-lg">⚠️</span>
                  <span>{mistake}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Summary & Tips */}
      <div className="grid md:grid-cols-3 gap-8 animate-fade-in-up" style={{ animationDelay: '0.6s' }}>
        <div className="md:col-span-2 bg-gradient-to-br from-brand-600 to-brand-800 rounded-[2rem] p-8 sm:p-10 text-white shadow-2xl shadow-brand-900/20 relative overflow-hidden border border-white/10 hover:scale-[1.01] transition-transform duration-400 ease-spring">
           <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full blur-3xl transform translate-x-1/2 -translate-y-1/2"></div>
          <h2 className="text-2xl font-bold mb-6 relative z-10">Summary</h2>
          <p className="opacity-95 leading-loose text-lg relative z-10 font-medium">
            {data.summary}
          </p>
        </div>

        <div className="glass-card rounded-[2rem] p-8 hover:scale-[1.02] transition-transform duration-400 ease-spring">
           <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center">
             <span className="text-2xl mr-2">🎯</span> Exam Tips
           </h2>
           <ul className="space-y-4">
             {data.examTips.map((tip, i) => (
               <li key={i} className="text-sm text-gray-700 dark:text-gray-300 flex items-start bg-gray-50/50 dark:bg-gray-800/50 p-4 rounded-2xl border border-gray-100/50 dark:border-gray-700/50 transition-colors hover:bg-white dark:hover:bg-white/5">
                 <span className="font-bold text-brand-500 mr-3 text-lg">{i+1}.</span>
                 <span className="mt-0.5 font-medium">{tip}</span>
               </li>
             ))}
           </ul>
        </div>
      </div>
    </div>
  );
};